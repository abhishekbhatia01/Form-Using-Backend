// const express = require('express');
// const app = express();
// const path = require('path');
// const fs = require('fs');

// app.use(express.urlencoded({ extended: true }));
// app.use(express.json());
// app.use(express.static(path.join(__dirname,'Assets')));

// app.set('view engine','ejs');

// app.get('/', (req, res) => {
//     const files = []; // Initialize files, even if empty.
//     res.render('index', { files }); // Pass 'files' to the template.
// });


// app.get('/',function(req, res){
//     fs.readdir('./files',function(err,files){
//         res.render("index",{files:files});
//     })
// })

// // app.post('/create',function(req,res){
// //     const title = req.body.title?.split(' ').join('');
// //     fs.writeFile(`./files/${title}.txt`,function(err){
// //         res.redirect('/');
// //     })
// // })
// app.post('/create', (req, res) => {
//     const title = req.body.title?.split(' ').join(''); // Replace spaces with no spaces.
//     const details = req.body.details; // This should contain the form data.

//     if (!title || !details) {
//         return res.status(400).send('Title and details are required.');
//     }

//     // Save to file.
//     fs.writeFile(`./files/${title}.txt`, details, (err) => {
//         if (err) {
//             return res.status(500).send('Error saving file');
//         }
//         res.redirect('/');
//     });
// });

// app.listen(3000);


const express = require('express');
const app = express();
const path = require('path');
const fs = require('fs');

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'Assets')));

app.set('view engine', 'ejs');

const filesDir = path.join(__dirname, 'files');

app.get('/', (req, res) => {
    fs.readdir(filesDir, (err, files) => {
        if (err) {
            return res.status(500).send('Error reading files');
        }
        res.render('index', { files });
    });
});

app.post('/create', (req, res) => {
    const { fname, lname, dob, sex, height, weight, contact, email, address, emergency_contact, relation } = req.body;

    const formData = `
    First Name: ${fname}
    Last Name: ${lname}
    Date of Birth: ${dob}
    Sex: ${sex}
    Height: ${height} inches
    Weight: ${weight} pounds
    Contact Number: ${contact}
    Email: ${email}
    Address: ${address}
    Emergency Contact: ${emergency_contact}
    Relation: ${relation}
    `;

    const sanitizedTitle = `${fname}_${lname}_${dob}`.split(' ').join('');
    const filename = `${sanitizedTitle}.txt`;
    const filepath = path.join(filesDir, filename);

    // Write the details into a file
    fs.writeFile(filepath, formData, (err) => {
        if (err) {
            return res.status(500).send('Error saving the file');
        }
        res.redirect('/');
    });
});
app.listen(3000);




